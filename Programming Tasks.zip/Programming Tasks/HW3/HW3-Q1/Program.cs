
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
//HW3-Q5
//I have created a dictionary called seenFiles to store the hash and the path of the corresponding file.
//Afterwards I have used a foreach loop to loop over all the files in a particular folder.
//I then in the same line have created a hash of each file by using ".ReadAllBytes" to load into memory and the passed those bytes into
"SHA256".
//To then make the user understand the hash, I converted it into a string.
//I then outputted all the contents that have been duplicated.
//I also decided to use serialization and create .txt file for the duplicate contents.
Dictionary<String, String> seenFiles = new Dictionary<string, string>();
string directory = "C:\\Users\\Ammar\\Documents\\PROGRAMMING\\test";
var Files = Directory.GetFiles(directory);
foreach (var item in Files)
{
String final = "";
try
{

final = Encoding.UTF8.GetString(SHA256.Create()
.ComputeHash(File.ReadAllBytes(item)
)
);
}
catch (Exception)
{
Console.WriteLine("There was an error in the process");
}
try
{
if (seenFiles.ContainsValue(final)
)
{
Console.WriteLine("In this directory these are the file contents that have been duplicated : " + File.ReadAllText(item)
);
Console.ReadLine();
Console.Write("Please name the file the duplicate contents should be stored in : ");
string filename = Console.ReadLine();
FileStream file = File.OpenWrite(filename + ".txt");
BinaryFormatter bf = new BinaryFormatter();
bf.Serialize(file, final);
file.Close();
break;
}
else
{
Console.WriteLine(File.ReadAllText(item)
);
seenFiles.Add(item, final);
}
}
catch (Exception e)
{
Console.WriteLine(e.ToString()
);
}
}
