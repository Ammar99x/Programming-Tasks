﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;

//**QUESTION - E1**
//GIVEN A LIST OF USERNAMES, USE THE WHERE FUCTION TO FILTER IT TO CREATE A COLLECTION CONTAINING ONLY USERNAMES THAT CONTAIN_AN_UNDERSCORE.


class Program
{

    static void Main(string[] args)

    {
        List<string> User = new List<string>(); // CREATED A LIST OF USERS
        
        User.Add("Timothy99");   // ADDING ALL THESE USERS IN
        User.Add("James_Don");
        User.Add("Harrry89");
        User.Add("Terry_timmy89");
        User.Add("shirley56");
       
        while (true)
        {
            Console.WriteLine(" ");
            Console.WriteLine("1) Display User list");  // GIVE USER OPTIONS TO DO SOMETHING WITH THAT LISTS OF USERS
            Console.WriteLine("2) Add to User list");
            Console.WriteLine("3) Remove from User list");
            Console.WriteLine("4) Display number of Users");
            Console.WriteLine("5) Display number of Users Only containing '_'");
            Console.WriteLine("6) Save Information");
            Console.WriteLine("Q) Quit");
            Console.WriteLine(" ");

            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine().ToLower();

            if (choice == "q") break;

            if (choice == "1") Display();  // INPUT KEYS, THIS CORRESPONDS TO WHAT THE USER WANTS TO DO
            else if (choice == "2") Add();
            else if (choice == "3") Remove();
            else if (choice == "4") Count();
            else if (choice == "5") Filter_();
            else if (choice == "6") Save();
            else Console.WriteLine("Unknown option.");
        }


        void Display()
        {
            foreach (string guest in User)
            {
               
                Console.WriteLine(guest);    // THIS DISPLAYS THE LIST
            }
        }

        void Add()
        {
            Console.Write("Please enter user name to add: ");
            string name = Console.ReadLine();
            if (User.Contains(name) == false)
            {
                User.Add(name);  // THIS ADDS THE NAME
         

            }
        }

        void Remove()
        {
            Console.Write("Please enter user name to remove: ");
            string name = Console.ReadLine(); //THIS REMOVES THE NAME
            User.Remove(name);
         
        }

        void Filter_()
        {
            foreach (string User in User) 
            {

                Console.WriteLine(User.Contains("_")); //THIS GIVES A BOOLEAN RESPONSE ON WHICH USERS CONTAIN "_" IN THERE NAME
               
            }
        }

        void Count()
        {
            Console.WriteLine("There are " + User.Count + " Users"); // THIS COUNTS THE AMOUNT OF USERS
         
        }
        void Save()
        {
            Console.Write("Please name the file the duplicate contents should be stored in : ");

            string filename = Console.ReadLine();
            FileStream file = File.OpenWrite(filename + ".txt");
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(file, User);
            file.Close();
        }
        
    }

    class User
    {
        public string Name;
    }

}


