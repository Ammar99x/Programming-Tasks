﻿using System;
using System.Linq;
using System.Collections.Generic;

List<int> numbers= new List<int> { 4, 3, 256, 80, 7, 46 };
bool result = numbers.All(nm => nm <= 256);

foreach (int nm in numbers)
   {

       Console.WriteLine(result);

   }


