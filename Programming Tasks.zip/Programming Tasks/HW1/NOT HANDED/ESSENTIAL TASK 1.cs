﻿using System;

string action1 = WhatIsNext();
string action2 = WhatIsNext();
string action3 = WhatIsNext();



String WhatIsNext()
{
    Console.Write("What Is Next: ");
    string action = Console.ReadLine();

    if (action == "Make Dinner")
    Console.WriteLine("Eat dinner and watch something");
    
    if (action == "Read a book")
    Console.WriteLine("Sleep");

    if (action == "Sleep")
    Console.WriteLine("Shower");

    return action;
}