﻿using System;
using System.Linq;
using System.Collections.Generic;

//**QUESTION - E1**
//GIVEN A LIST OF USERNAMES, USE THE WHERE FUCTION TO FILTER IT TO CREATE A COLLECTION CONTAINING ONLY USERNAMES THAT CONTAIN_AN_UNDERSCORE.




//** FEEDBACK **
//You need to make sure to focus on the basics here. The indentation is all a little off. Spend some time keeping your code tidy, it pays off in the long run.
//You've used an algorithm function effectively here, good work.
//For higher marks it would have been good to see some other features, perhaps by adding some extra fields onto the User class and doing something with that data too.


List<User> listOfUsers = new List<User>()  

{
new User() { Name = "Timothy99"},
new User() { Name = "James_Don"},
new User() { Name = "Harrry89"},
new User() { Name = "Terry_timmy89"},
new User() { Name = "shirley56"},
};

var filteredUsers = listOfUsers.Where(user => user.Name.Contains("_"));

foreach (User user in filteredUsers)
Console.WriteLine(user.Name);

class User
{
public string Name;
}

