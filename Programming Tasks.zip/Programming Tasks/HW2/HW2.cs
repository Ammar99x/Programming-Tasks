using System;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length != 3)
        {
            Console.WriteLine("");
            Console.WriteLine("Please enter two numbers in this format 'a + b'");
            return;
        }


        int a = 0;
        int b = 0;
        string op = args[1];

        try
        {
            a = Convert.ToInt32(args[0]);
            b = Convert.ToInt32(args[0]);
        }
        catch (FormatException)
        {
            Console.WriteLine("");
            Console.WriteLine("we’re not ready for that yet!");
            return;
        }
        if (op)
        {
            case "+":
                Console.WriteLine(string.Join(" ", args) + " = " + (a + b)); break;
            default:
                Console.WriteLine("");
                Console.WriteLine("This is not the right operation, please use the addition sign : + "); break;
        }
        els
        


    }
}