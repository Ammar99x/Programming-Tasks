﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

class Program
{
    static void Main(string[] args)
    {   

        if (args.Length != 3)
        {
            Console.WriteLine("");
            Console.WriteLine("Please enter two numbers in this format 'a + b'");
            return;
        }
        else if (args.Length == 0)
        {
            Console.WriteLine("");
            Console.WriteLine("No numbers were entered");
            return;
        }


        try
        {

            int a = Convert.ToInt32(args[1]);
            int b = Convert.ToInt32(args[2]);
            string op = args[1];
            
            if (op == "+")
            {
                int res = a + b;
                Console.WriteLine(a + "+ " + b + "=" + res);
            }
            else if (op == "x")
            {
                int res = a - b;
                Console.WriteLine(a + "x " + b + "=" + res);
            }
            else if (op == " - ")
            {
                int res = a - b;
                Console.WriteLine(a + "- " + b + "=" + res);
            }
            else if (op == "/")
            {
                int res = a / b;
                Console.WriteLine(a + "/ " + b + "=" + res);
            }

        }
        catch (FormatException)
        {
            Console.WriteLine("");
            Console.WriteLine("we’re not ready for that yet!");
            return;
        }
        catch (ArgumentOutOfRangeException)
        {
            Console.WriteLine("");
            Console.WriteLine("Not in range, please enter correctly.");
            return;
        }
        catch (IndexOutOfRangeException)
        {
            Console.WriteLine("");
            Console.WriteLine("Not enough");
            return;
        }

    }
}