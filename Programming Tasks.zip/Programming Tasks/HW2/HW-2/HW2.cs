﻿using System;

//Write a command line program which lets the user do quick mathematical operations on the command line.
//The first argument they supply is the operation to perform, the remaining arguments are the values to use for that operation.
//The number of values supplied can vary depending on the operation.


class Program
{
    static void Main(string[] args)
    {
        if (args.Length != 3)
        {
            Console.WriteLine("");
            Console.WriteLine("Please enter two numbers in this format 'a + b'");
            return;
        }

        int a = 0;
        int b = 0;
        string op = args[1];

        try
        {
            a = Convert.ToInt32(args[0]);
            b = Convert.ToInt32(args[0]);
        }
        catch (FormatException)
        {
            Console.WriteLine("");
            Console.WriteLine("we’re not ready for that yet!");
            return;
        }
        switch (op)
        {
            case "+":
                Console.WriteLine(string.Join(" ", args) + " = " + (a + b)); break;
            default:
                Console.WriteLine("");
                Console.WriteLine("This is not the right operation, please use the addition sign : + "); break;
        }


    }
}